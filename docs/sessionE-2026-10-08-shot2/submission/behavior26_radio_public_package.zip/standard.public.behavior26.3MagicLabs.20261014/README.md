# BEHAVIOR 2026 Challenge Submission

Package: `standard.public.behavior26.3MagicLabs.20261014`
Track: **standard** · Test set: **public** · Team: **behavior26** (3MagicLabs)

## What this is

A π₀.₅-based policy served over the websocket protocol the BEHAVIOR-1K evaluator
speaks. `json/` holds 20 unmodified per-rollout metrics files.

## How to evaluate this policy

### 1. Start the policy server

The Docker image serves the policy over the websocket protocol described below, within a single 24GB VRAM GPU.

- Image / endpoint: TODO -- fill in before submitting

The server must implement the protocol in
`omnigibson/eval/utils/network_utils.py`:

- answer `GET /healthz` with 2xx on the same host:port;
- on websocket connect, send **one msgpack metadata frame first** — the client
  blocks on `unpackb(conn.recv())` before sending anything;
- for each observation frame, reply `{"action": <ndarray>}`. The value must
  decode to a real `numpy.ndarray` (the client calls `th.from_numpy` on it), and
  its width must equal `robot.action_dim` (23 for R1Pro);
- ndarrays use the evaluator's own msgpack extension
  (`{b"__ndarray__": True, b"data", b"dtype", b"shape"}`), **not** msgpack-numpy;
- a `{"reset": True}` frame expects **no reply**.

### 2. Run the evaluator

```
python -m omnigibson.eval.eval \
  --task-name $TASK \
  --host 127.0.0.1 \
  --port 8000 \
  --mode public_test \
  --instance-indices 0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 \
  --num-rollouts 1 \
  --env-wrapper omnigibson.eval.wrappers.RGBDFullResWrapper \
  --robot-config r1pro.yaml \
  --output-dir outputs/eval \
  --write-video
```

`--instance-indices` are **indices into the split**, not instance ids. For
`--mode public_test` they index `TEST_INSTANCE_IDS[:20]`,
i.e. instances **301–320**. Result filenames carry the resolved id.

### 3. Score

```
python -m omnigibson.eval.utils.score_utils --input-dir standard.public.behavior26.3MagicLabs.20261014 --output-dir scores/
```

The directory name is parsed as `<track>.<testset>.<team>.<affiliation>.<date>`,
which is why the package is laid out that way.

## Contents

| File | Purpose |
|---|---|
| `json/` | 20 rollout metrics files, unmodified |
| `rgbd_full_res_wrapper.py` | Evaluation wrapper. Exposes RGB, depth and proprioception only. |
| `r1pro.yaml` | Exact robot config used for evaluation |


## Rollout videos

TODO -- submit the link to all rollout MP4s through the portal.

MP4s are not zipped; they are submitted as a link through the portal.

## Observation compliance

The wrapper exposes only RGB, depth and proprioception. No ground-truth
segmentation, object state, target object pose, full-scene point cloud, or robot
global pose is read from the simulator at evaluation time. The environment is not
manipulated directly — no teleporting the robot and no setting object states.
